set -u
cd "$(git rev-parse --show-toplevel)"
LOG="$PWD/apply-log.txt"; : > "$LOG"
say() { echo "$*" | tee -a "$LOG"; }
ZIPS=$(git ls-files '*.zip')
STATUS=ok

say "== 1. APPLICO LE MODIFICHE =="
if git am --3way change.patch >> "$LOG" 2>&1; then say OK
else git am --abort 2>/dev/null; say "ERRORE: patch non applicabile"; rm -f change.patch apply.sh; exit 1; fi
rm -f change.patch

say "== 2. FRONTEND: typecheck, test, build =="
if (cd frontend && npm ci --silent && npm run -s typecheck && npx vitest run && npm run -s build) > /tmp/npm.log 2>&1; then
  grep -E "Tests " /tmp/npm.log | tee -a "$LOG"; say OK
else tail -40 /tmp/npm.log | tee -a "$LOG"; STATUS=fail; fi
rm -rf frontend/dist

say "== ESITO: $STATUS =="
rm -f apply.sh
[ -n "$ZIPS" ] && git rm -q $ZIPS
git add -A
git commit -q --amend --reset-author --no-edit
git push -q origin main
echo "PUBBLICATO - esito: $STATUS"
if [ "$STATUS" = ok ]; then bash scripts/dev.sh; else echo "Ci sono errori: scrivi a Claude."; fi
